import Image from 'next/image';

export default function Footer() {
  return (
    <footer className="w-full bg-[#24135F] text-white py-6 px-4">
      <div className="container mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Social Media Icons */}
        <div className="flex space-x-4 rtl:space-x-reverse mb-2 md:mb-0">
          <a href="#" aria-label="LinkedIn"><Image src="/assets/socialmedia-icons/linkedin.png" alt="LinkedIn" width={32} height={32} /></a>
          <a href="#" aria-label="Instagram"><Image src="/assets/socialmedia-icons/instagram.png" alt="Instagram" width={32} height={32} /></a>
          <a href="#" aria-label="X"><Image src="/assets/socialmedia-icons/x.png" alt="X" width={32} height={32} /></a>
          <a href="#" aria-label="WhatsApp"><Image src="/assets/socialmedia-icons/whatsapp.png" alt="WhatsApp" width={32} height={32} /></a>
        </div>
        {/* Contact Info */}
        <div className="text-center text-sm">
          <div className="mb-1">العنوان: السد، المرقاب الجديد، مقابل الرقايب مول، مبنى 50 الدور الأول مكتب 4</div>
          <div className="mb-1">أرقام التواصل: +974 6664 6448 - +974 6610 3661</div>
          <div className="mb-1">الإيميل: info@thebrightvision.qa</div>
        </div>
        {/* Copyright */}
        <div className="text-xs text-[#F94239] font-bold">جميع الحقوق محفوظة © The Bright Vision 2025</div>
      </div>
    </footer>
  );
} 