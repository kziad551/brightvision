import nodemailer from 'nodemailer';

export async function POST(req) {
  try {
    const { name, email, phone, message } = await req.json();
    if (!name || !email || !message) {
      return new Response(JSON.stringify({ error: 'جميع الحقول مطلوبة.' }), { status: 400 });
    }

    // Configure nodemailer transporter (using Gmail SMTP for example)
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.CONTACT_EMAIL_USER, // set in .env.local
        pass: process.env.CONTACT_EMAIL_PASS  // set in .env.local
      }
    });

    const mailOptions = {
      from: `Bright Vision Website <${process.env.CONTACT_EMAIL_USER}>`,
      to: 'kziad551@gmail.com',
      subject: 'رسالة جديدة من نموذج التواصل',
      text: `
الاسم: ${name}
البريد الإلكتروني: ${email}
رقم الهاتف: ${phone}

الرسالة:
${message}
      `,
      html: `<div dir="rtl" style="font-size:18px;line-height:1.7"><b>الاسم:</b> ${name}<br/><b>البريد الإلكتروني:</b> ${email}<br/><b>رقم الهاتف:</b> ${phone}<br/><br/><b>الرسالة:</b><br/>${message.replace(/\n/g, '<br/>')}</div>`
    };

    await transporter.sendMail(mailOptions);
    return new Response(JSON.stringify({ success: true }), { status: 200 });
  } catch (err) {
    console.error("Nodemailer error:", err); // Log the detailed error to the server console
    // Also, let's include the error message in the response for easier debugging if needed,
    // but be careful with exposing too much detail in a production environment.
    return new Response(JSON.stringify({ error: 'فشل إرسال الرسالة. حاول مرة أخرى.', details: err.message || String(err) }), { status: 500 });
  }
} 