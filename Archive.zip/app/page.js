'use client';
import Image from "next/image";
import { useEffect, useRef } from "react";
import ClientsSlider from "../components/ClientsSlider";
import Link from "next/link";

const services = [
  {
    icon: "/assets/servicesIcons/Group 29.png",
    title: "الاستشارات والتخطيط الاستراتيجي",
    desc: "استشارات العلامة التجارية وتطوير الهوية وتحليل السوق والمنافسين وبناء استراتيجيات النمو وإطلاق الخدمات",
  },
  {
    icon: "/assets/servicesIcons/dslr-camera 1.png",
    title: "الإنتاج الإعلامي والتصوير",
    desc: "تصوير فوتوغرافي، إنتاج وإخراج فيديوهات، سبوتات، قصص وطابية مواقع إعلانات باستخدام أحدث التقنيات",
  },
  {
    icon: "/assets/servicesIcons/Glyph.png",
    title: "تصميم الهوية البصرية",
    desc: "تصميم الشعارات والهويات البصرية وتطوير العلامات التجارية وتحريك الشعارات",
  },
  {
    icon: "/assets/servicesIcons/domain (1) 2.png",
    title: "تصميم وتطوير المواقع والتطبيقات",
    desc: "تطوير مواقع إلكترونية وتطبيقات بأنظمتها المختلفة تصميم متاجر - مواقع - برمجة مخصصة",
  },
  {
    icon: "/assets/servicesIcons/cost 1.png",
    title: "الإعلانات الرقمية والتسويق الممول",
    desc: "إدارة حملات جوجل وفيسبوك والحملات على تيك توك وسناب شات التسويق عبر المؤثرين",
  },
  {
    icon: "/assets/servicesIcons/Vector.png",
    title: "إدارة منصات التواصل الاجتماعي",
    desc: "إدارة حسابات استراتيجيات السوشيال ميديا، ابتكار أفكار، صناعة المحتوى والردود اليومية",
  },
];

const clients = [
  "/assets/clientslogos/logo in circle RGB white (1).png",
  "/assets/clientslogos/lathat el forn logo png.png",
  "/assets/clientslogos/5.png",
  "/assets/clientslogos/white logo png.png",
  "/assets/clientslogos/Layer 1.png",
  "/assets/clientslogos/mia bello white logo png.png",
  "/assets/clientslogos/logo in circle RGB white.png",
];

export default function Home() {
  const sliderRef = useRef(null);
  useEffect(() => {
    const slider = sliderRef.current;
    let scrollAmount = 0;
    const interval = setInterval(() => {
      if (slider) {
        scrollAmount += 1;
        if (scrollAmount >= slider.scrollWidth / 2) scrollAmount = 0;
        slider.scrollLeft = scrollAmount;
      }
    }, 20);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4">
        <div className="absolute inset-0 bg-white z-0"></div>
        <div className="container mx-auto text-center z-10 mt-20">
          <h1 className="text-[120px] leading-[1.2] font-bold text-[#F94239] mb-8 max-w-[1200px] mx-auto">
            نحــــوّل الحُلـــم لعلامــــة
            <br />
            تَبقــــــــى وتَتـــــــرُك أثـــــــر
          </h1>
        </div>
        <div className="absolute bottom-12 left-0 right-0 z-10">
          <div className="flex justify-between items-center max-w-[1200px] mx-auto px-4">
            <Link href="#" className="text-[24px] font-[400] text-[#F94239]">بصمتـــــك تسبقـــــك</Link>
            <Link href="#" className="text-[24px] font-[400] text-[#F94239]">الـمحتوى عندنـــا، ماهو شغـــل.. هو شغــــف</Link>
          </div>
          <div className="w-full max-w-[1200px] mx-auto border-t border-[#F94239] mt-4 px-4"></div>
        </div>
      </section>

      {/* About Us Section */}
      <section className="relative bg-[#24135F] text-white py-32 px-4 overflow-hidden">
        {/* Decorative SVG Shape */}
        <svg
          className="absolute top-1/2 -right-24 w-[400px] h-[400px] transform -translate-y-1/2 z-0 opacity-30"
          viewBox="0 0 400 400"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          preserveAspectRatio="xMidYMid meet"
        >
          <path
            d="M350 100 C 350 50, 300 0, 250 0 C 200 0, 150 50, 150 100 L 150 200 C 150 250, 100 300, 50 300 C 0 300, -50 250, -50 200"
            stroke="#F94239"
            strokeWidth="3"
            fill="none"
          />
        </svg>

        <div className="container mx-auto max-w-4xl relative z-10">
          <h2 className="text-[#F94239] text-[80px] font-[500] mb-16 text-right">عنــــا</h2>
          <div className="text-center max-w-2xl mx-auto space-y-6 text-[24px] leading-[1.8] font-normal">
            <p>تأسست شركة ذا برايت فيجن في عام 2019.</p>
            <p>ونمت بسرعة لتصبح من أبرز شركات التسويق والإعلان في الشرق الأوسط.</p>
            <p>يقع مقرنا الرئيسي في قطر، ونعمل على التوسع في دول الخليج ولبنان ومصر.</p>
          </div>
          <div className="text-center max-w-2xl mx-auto mt-12 space-y-6 text-[24px] leading-[1.8] font-normal">
            <p>منذ البداية، كان هدفنا واضحاً:</p>
            <p>نساعد العلامات التجارية على التميز من خلال أفكار إبداعية واستراتيجيات ذكية تحقق نتائج حقيقية.</p>
          </div>
          <div className="text-center">
            <a href="#" className="text-[#F94239] text-[24px] hover:underline inline-block mt-12">عرض المزيد ...</a>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="relative py-32 px-4 bg-[#24135F] overflow-hidden">
        {/* Background Shape */}
        <div 
          className="absolute inset-0 z-0"
          style={{
            background: `url('/assets/servicesBackround.png') no-repeat center center`,
            backgroundSize: 'cover'
          }}
        />

        <div className="container mx-auto relative z-10">
          <div className="flex justify-between items-center mb-16">
            <h2 className="text-white text-[80px] font-[500]">خدمــاتنــــــا</h2>
            <Link 
              href="#" 
              className="bg-[#F94239] text-white text-[20px] rounded-full px-8 py-3 hover:opacity-90 transition border-2 border-[#F94239]"
            >
              كل الخدمات
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12 mt-20">
            {services.map((service, idx) => (
              <div key={idx} className="text-right">
                <div className="flex items-start gap-4 mb-4">
                  <div className="bg-white rounded-full p-4 w-[60px] h-[60px] flex items-center justify-center flex-shrink-0">
                    <Image 
                      src={service.icon} 
                      alt={service.title} 
                      width={32} 
                      height={32} 
                      className="object-contain" 
                    />
                  </div>
                  <h3 className="text-[17px] font-[700] text-[#24135F] leading-tight mt-4">
                    {service.title}
                  </h3>
                </div>
                <p className="text-[14px] font-[400] text-white leading-relaxed pr-[76px]">
                  {service.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Works Section */}
      <section className="py-32 px-4">
        <div className="container mx-auto">
          <h2 className="text-[#24135F] text-[80px] font-[500] mb-16 text-right">أعمــالنــــا</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[1,2,3,4].map((i) => (
              <div key={i} className="aspect-square bg-gray-100 rounded-lg"></div>
            ))}
          </div>
        </div>
      </section>

      {/* Clients Section */}
      <section className="bg-[#24135F] py-32 px-4">
        <div className="container mx-auto">
          <h2 className="text-[#F94239] text-[80px] font-[500] mb-16 text-right">عملاؤنــــا</h2>
          <ClientsSlider clients={clients} />
        </div>
      </section>
    </div>
  );
}